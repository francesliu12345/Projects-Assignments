Time Spent on Social Media Study

For this study, our group chose the “Time Spent on Social Media” dataset.

Link to dataset: https://www.kaggle.com/datasets/imyjoshua/average-time-spent-by-a-user-on-social-media

The RScript file aims to make predictions and analysis on patterns Social Media Usage by applying various statistics and data visualization methods with R Studio.

Basic descriptive statistics and chart plots using ggplot2 are generated in order to assist in data analysis.

**Note: Not all graphs generated are transferred into actual report, but serve as evidence of analysis in decisions making (Pie charts of countries and timespent, normal distribution).